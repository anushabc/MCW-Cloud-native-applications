CREATE USER [asa.sql.staging]
    FOR LOGIN [asa.sql.staging]
    WITH DEFAULT_SCHEMA = dbo
GO

-- Add user to the required roles

EXEC sp_addrolemember N'db_datareader', N'asa.sql.staging'
GO

EXEC sp_addrolemember N'db_datawriter', N'asa.sql.staging'
GO

EXEC sp_addrolemember N'db_ddladmin', N'asa.sql.staging'
GO