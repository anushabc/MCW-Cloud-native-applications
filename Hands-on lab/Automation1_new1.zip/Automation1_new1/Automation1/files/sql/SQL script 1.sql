CREATE DATABASE SQLOnDemand01
CREATE CREDENTIAL [https://<primary_storage>.dfs.core.windows.net]
WITH IDENTITY='User Identity';