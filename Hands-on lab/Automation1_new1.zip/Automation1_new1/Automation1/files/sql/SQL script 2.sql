CREATE LOGIN [asa.sql.staging]
WITH PASSWORD = '<password>'
GO