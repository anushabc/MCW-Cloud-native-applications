CREATE USER [<workspace>] FROM EXTERNAL PROVIDER;

--Granting permission to the identity
GRANT CONTROL ON DATABASE::<sqlpool> TO [<workspace>];