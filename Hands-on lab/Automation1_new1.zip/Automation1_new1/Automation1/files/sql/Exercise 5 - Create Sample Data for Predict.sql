DROP TABLE [wwi].[SampleData]; 
GO

CREATE TABLE [wwi].[SampleData] 
(
    [customerkey] REAL, 
    [stockitemkey] REAL
);
GO

INSERT INTO [wwi].[SampleData] ([customerkey], [stockitemkey])
VALUES ( 11, 1 );
GO

SELECT * FROM [wwi].[SampleData];
GO

CREATE TABLE [wwi].[SampleData] 
(
    [features] REAL,
    [features2] REAL
);
GO

INSERT INTO [wwi].[SampleData] ([features], [features2])
VALUES ( 11, 1 );
GO

SELECT * FROM [wwi].[SampleData];
GO